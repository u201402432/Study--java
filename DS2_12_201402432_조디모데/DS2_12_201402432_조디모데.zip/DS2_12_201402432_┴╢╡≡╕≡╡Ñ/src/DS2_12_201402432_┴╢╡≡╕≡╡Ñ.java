public class DS2_12_201402432_����� {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AppController appController = new AppController() ;
		appController.run();
	
		
	}

}
