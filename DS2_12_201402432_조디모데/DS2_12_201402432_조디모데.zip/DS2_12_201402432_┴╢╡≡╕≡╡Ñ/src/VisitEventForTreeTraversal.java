public interface VisitEventForTreeTraversal {
	public void processVisitByCallback(Object anObj);
}
