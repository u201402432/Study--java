public class DS2_09_201402432_����� {

	public static void main(String[] args) {

		AppControllor app = new AppControllor() ;
		app.run() ;
	}
	
}
