
public enum MessageID {
	Notice_StartProgram, 
	Notice_ShowOriginalInput, 
	Notice_ShowResultInput, 
	Notice_EndProgram

}
