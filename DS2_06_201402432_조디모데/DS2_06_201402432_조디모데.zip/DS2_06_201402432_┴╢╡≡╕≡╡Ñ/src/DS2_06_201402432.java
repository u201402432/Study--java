public class DS2_06_201402432 {

	public static void main(String[] args) {

		AppController appController = new AppController() ;
		appController.run() ;


	}

}
