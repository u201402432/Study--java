public enum MessageID {

	// Message IDs for Notices:
	Notice_StartProgram, 
	Notice_EndProgram,
	Notice_ShowGraph, 
	// MessageIDs for Errors:
	Error_FailInputGraph, 
	Error_WrongEdge, 
	Notice_ShowDistance, 
	Notice_ShowPath, 

	
}
