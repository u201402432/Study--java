
public class DS2_03_201402432_����� {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Application appController = new Application() ;
		appController.run();
		
	}

}
